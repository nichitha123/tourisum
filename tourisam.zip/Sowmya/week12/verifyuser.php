<!--verifyuser.php-->
<html>
	<body>
		<form name="f2" method="post" action="verify.php">
			<center>
				<table border="2" >
					<caption style="color:red"> verify user </caption>
					<tr>
						<td> User Name :</td>
						<td> <input type="text" name="un" size=30 required="required"></td>
					</tr>
					<tr>
						<td> Password : </td>
						<td> <input type="password" name="pw" size=30 required="required"> </td>
					</tr>
					<tr>
						<td align="left" colspan=2><input type="Submit" value="verify me"></td>
					</tr>
				</table>
			</center>
		</form>
	</body>
</html>