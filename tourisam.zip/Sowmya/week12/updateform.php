<!--updateform.php-->
<html>
	<body>
		<form name="f2" method="post" action="update.php">
		<center>
			<table border="2">
				<caption style="color:red">Register Window</caption>
				<tr>
					<td>User Name:</td>
					<td><input type="text" name="unn" size=30></td>
				</tr>
				<tr>
					<td>Old Password:</td>
					<td><input type="password" name="opw" size=30></td>
				</tr>
				<tr>
					<td>New Password:</td>
					<td><input type="password" name="npw" size=30></td>
				</tr>
				<tr>
					<td></td>
					<td align="left">
						<input type="Submit" value="UPDATE">  &nbsp;&nbsp;
						<input type="reset" value="Clear">
					</td>	
				</tr>
			</table>
		</center>
	</body>
</html>
