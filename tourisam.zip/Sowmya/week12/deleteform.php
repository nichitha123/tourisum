<!--deleteform.php-->
<html>
	<body>
		<form name="f2" method="post" action="deleteuser.php">
		<center>
			<table border="2" >
			<caption style="color:red"> Register Window </caption>
				<tr>
					<td> User Name :</td>
					<td> <input type="text" name="user" size=30 ></td>
				</tr>
				<tr>
					<td align="left" ><input type="Submit" value="Delete"> &nbsp;&nbsp;
					<input type="reset" value="Clear"></td>
				</tr>
			</table>
		</center>
		</form>
	</body>
</html>

