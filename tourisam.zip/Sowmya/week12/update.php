<!--update.php-->
<html>
	<body>
		<?php
			$con=mysqli_connect('localhost','root','','sowmya');
			if(!$con)
			{
				die('Error in Connection'.mysqli_error());
			}
			$sel = mysqli_select_db($con,'sowmya');
			if(!$sel)
				echo "<br>Database is not selected Successfully";
			//Getting form Database
			$un = $_POST["unn"];
			$old = $_POST["opw"];
			$ne = $_POST["npw"];
			
			mysqli_query($con , "UPDATE login SET pword='$ne' WHERE pword='$old'");
			echo "<br> Updated User Data Successfully";
			echo "<br><a href='login.php'>Move to Home Page</a>";
			mysqli_close($con);
		?>	
	</body>
</html>