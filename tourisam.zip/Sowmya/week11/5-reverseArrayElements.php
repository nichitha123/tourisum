<!--PHP program to reverse array elements-->
<html>
	<head>
		<title>Array Reverse Sort</title>
	</head>
	<body>
		<?php
			$arr = array(2,6,1,8,3);
			echo "The array before sorting is  ";
			for($i=0; $i<count($arr); $i++)
				echo $arr[$i];
			echo "<br>";
			for($i=0; $i<count($arr); $i++)
				for($j=$i+1; $j<count($arr); $j++)
					if($arr[$i] < $arr[$j])
					{
						$temp=$arr[$i];
						$arr[$i]=$arr[$j];
						$arr[$j]=$temp;
					}
			echo "Sorted order of elements is  ";
			for($i=0; $i<count($arr); $i++)
				echo $arr[$i];
			
			$arr1= array(5,7,2,9,0,1,4);
			rsort($arr1);
			echo "<br>";
			echo "The sorted order of elements using sort in-built function is  ";
			foreach($arr1 as $x)
			{
				echo $x;
			}
		?>
	</body>
</html>