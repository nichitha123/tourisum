<!--getdata.php-->
<html>
	<head>
		<title>Form Data</title>
	</head>
	<body>
		<h2>The data stored is</h2>
		<?php
			$name = $_GET["t1"];
			$no = $_GET["t2"];
			$city = $_GET["s1"];
			echo "The Name is ->".$name;
			echo "<br>";
			echo "The Mobile number is ->".$no;
			echo "<br>";
			echo "The City name is ->".$city;
		?>
	</body>
</html>