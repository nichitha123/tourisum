<!-- PHP program to find sum of array elements-->
<html>
	<head>
		<title>Sum of Array</title>
	</head>
	<body>
		<?php
			$arr = array(1,2,3,4,5);
			$sum=0;
			for($i=0; $i<count($arr); $i++)
				$sum = $sum + $arr[$i];
			echo "The sum of array elemets is ".$sum;
		?>
	</body>
</html>
