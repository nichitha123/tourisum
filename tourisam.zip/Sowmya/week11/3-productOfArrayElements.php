<!-- PHP program to find product of array elements-->
<html>
	<head>
		<title>Product of Array</title>
	</head>
	<body>
		<?php
			$arr = array(1,2,3,4,5);
			$product=1;
			for($i=0; $i<count($arr); $i++)
				$product = $product * $arr[$i];
			echo "The product of array elemets is ".$product;
		?>
	</body>
</html>