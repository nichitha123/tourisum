<!--postdata.php-->
<html>
	<head>
		<title>Form Data</title>
	</head>
	<body>
		<h2>The data stored is</h2>
		<?php
			$name = $_POST["t1"];
			$no = $_POST["t2"];
			$city = $_POST["s1"];
			echo "The Name is ->".$name."<br>";
			echo "The Mobile number is ->".$no."<br>";
			echo "The City name is ->".$city."<br>";
		?>
	</body>
</html>