<!--PHP program to demonstrate Assosiative arrays-->
<html>
	<head>
		<title> Assosiative Arrays</title>
	</head>
	<body>
		<?php
			$arr = array("Sowmya"=>548,"Nichitha"=>514,"Nithya"=>506);
			print_r($arr);
			echo "<br>";
			
			foreach($arr as $x=>$y)
			{
				echo $x." : ".$y;
				echo "<br>";
			}
		?>
	</body>
</html>
