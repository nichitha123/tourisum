<!-- Program to find factorial of a number using recursin-->
<html>
	<head>
		<title>FACTORIAL</title>
	</head>
	<body>
		<h2>Factorial of a number</h2>
		<?php
			function fact($n=7)
			{
				if($n==1)
					return 1;
				else
					return ($n*fact($n-1));
			}
			$x=fact(5);
			echo "The factorial of 5 is ".$x;
			echo "<br>";
			$y=fact();
			echo "The factorial of 7 is ".$y;
		?>
	</body>
</html>